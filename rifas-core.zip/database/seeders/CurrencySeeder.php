<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Currency;

class CurrencySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        Currency::create([
            'symbol' => 'VEF',
            'name' => 'Bolivar',
        ]);     

        Currency::create([
            'symbol' => 'USD',
            'name' => 'Dolar',
        ]);
        Currency::create([
            'symbol' => 'EUR',
            'name' => 'Euro',
        ]);     
    }
}
