import Fortify from './Fortify'
const Laravel = {
    Fortify: Object.assign(Fortify, Fortify),
}

export default Laravel