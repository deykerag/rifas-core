import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RaffleController::winnerSearchView
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
export const winnerSearchView = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: winnerSearchView.url(options),
    method: 'get',
})

winnerSearchView.definition = {
    methods: ["get","head"],
    url: '/dashboard/winner-search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RaffleController::winnerSearchView
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
winnerSearchView.url = (options?: RouteQueryOptions) => {
    return winnerSearchView.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::winnerSearchView
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
winnerSearchView.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: winnerSearchView.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RaffleController::winnerSearchView
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
winnerSearchView.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: winnerSearchView.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RaffleController::winnerSearchView
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
    const winnerSearchViewForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: winnerSearchView.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RaffleController::winnerSearchView
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
        winnerSearchViewForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: winnerSearchView.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RaffleController::winnerSearchView
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
        winnerSearchViewForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: winnerSearchView.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    winnerSearchView.form = winnerSearchViewForm
/**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
export const findWinner = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: findWinner.url(options),
    method: 'post',
})

findWinner.definition = {
    methods: ["post"],
    url: '/dashboard/find-winner',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
findWinner.url = (options?: RouteQueryOptions) => {
    return findWinner.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
findWinner.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: findWinner.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
    const findWinnerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: findWinner.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
        findWinnerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: findWinner.url(options),
            method: 'post',
        })
    
    findWinner.form = findWinnerForm
/**
* @see \App\Http\Controllers\RaffleController::index
 * @see app/Http/Controllers/RaffleController.php:15
 * @route '/raffles'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/raffles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RaffleController::index
 * @see app/Http/Controllers/RaffleController.php:15
 * @route '/raffles'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::index
 * @see app/Http/Controllers/RaffleController.php:15
 * @route '/raffles'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RaffleController::index
 * @see app/Http/Controllers/RaffleController.php:15
 * @route '/raffles'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RaffleController::index
 * @see app/Http/Controllers/RaffleController.php:15
 * @route '/raffles'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RaffleController::index
 * @see app/Http/Controllers/RaffleController.php:15
 * @route '/raffles'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RaffleController::index
 * @see app/Http/Controllers/RaffleController.php:15
 * @route '/raffles'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RaffleController::create
 * @see app/Http/Controllers/RaffleController.php:26
 * @route '/raffles/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/raffles/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RaffleController::create
 * @see app/Http/Controllers/RaffleController.php:26
 * @route '/raffles/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::create
 * @see app/Http/Controllers/RaffleController.php:26
 * @route '/raffles/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RaffleController::create
 * @see app/Http/Controllers/RaffleController.php:26
 * @route '/raffles/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RaffleController::create
 * @see app/Http/Controllers/RaffleController.php:26
 * @route '/raffles/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RaffleController::create
 * @see app/Http/Controllers/RaffleController.php:26
 * @route '/raffles/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RaffleController::create
 * @see app/Http/Controllers/RaffleController.php:26
 * @route '/raffles/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\RaffleController::store
 * @see app/Http/Controllers/RaffleController.php:37
 * @route '/raffles'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/raffles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RaffleController::store
 * @see app/Http/Controllers/RaffleController.php:37
 * @route '/raffles'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::store
 * @see app/Http/Controllers/RaffleController.php:37
 * @route '/raffles'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RaffleController::store
 * @see app/Http/Controllers/RaffleController.php:37
 * @route '/raffles'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RaffleController::store
 * @see app/Http/Controllers/RaffleController.php:37
 * @route '/raffles'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RaffleController::show
 * @see app/Http/Controllers/RaffleController.php:0
 * @route '/raffles/{raffle}'
 */
export const show = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/raffles/{raffle}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RaffleController::show
 * @see app/Http/Controllers/RaffleController.php:0
 * @route '/raffles/{raffle}'
 */
show.url = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { raffle: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    raffle: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        raffle: args.raffle,
                }

    return show.definition.url
            .replace('{raffle}', parsedArgs.raffle.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::show
 * @see app/Http/Controllers/RaffleController.php:0
 * @route '/raffles/{raffle}'
 */
show.get = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RaffleController::show
 * @see app/Http/Controllers/RaffleController.php:0
 * @route '/raffles/{raffle}'
 */
show.head = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RaffleController::show
 * @see app/Http/Controllers/RaffleController.php:0
 * @route '/raffles/{raffle}'
 */
    const showForm = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RaffleController::show
 * @see app/Http/Controllers/RaffleController.php:0
 * @route '/raffles/{raffle}'
 */
        showForm.get = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RaffleController::show
 * @see app/Http/Controllers/RaffleController.php:0
 * @route '/raffles/{raffle}'
 */
        showForm.head = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\RaffleController::edit
 * @see app/Http/Controllers/RaffleController.php:72
 * @route '/raffles/{raffle}/edit'
 */
export const edit = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/raffles/{raffle}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RaffleController::edit
 * @see app/Http/Controllers/RaffleController.php:72
 * @route '/raffles/{raffle}/edit'
 */
edit.url = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { raffle: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    raffle: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        raffle: args.raffle,
                }

    return edit.definition.url
            .replace('{raffle}', parsedArgs.raffle.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::edit
 * @see app/Http/Controllers/RaffleController.php:72
 * @route '/raffles/{raffle}/edit'
 */
edit.get = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RaffleController::edit
 * @see app/Http/Controllers/RaffleController.php:72
 * @route '/raffles/{raffle}/edit'
 */
edit.head = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RaffleController::edit
 * @see app/Http/Controllers/RaffleController.php:72
 * @route '/raffles/{raffle}/edit'
 */
    const editForm = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RaffleController::edit
 * @see app/Http/Controllers/RaffleController.php:72
 * @route '/raffles/{raffle}/edit'
 */
        editForm.get = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RaffleController::edit
 * @see app/Http/Controllers/RaffleController.php:72
 * @route '/raffles/{raffle}/edit'
 */
        editForm.head = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\RaffleController::update
 * @see app/Http/Controllers/RaffleController.php:85
 * @route '/raffles/{raffle}'
 */
export const update = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/raffles/{raffle}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\RaffleController::update
 * @see app/Http/Controllers/RaffleController.php:85
 * @route '/raffles/{raffle}'
 */
update.url = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { raffle: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    raffle: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        raffle: args.raffle,
                }

    return update.definition.url
            .replace('{raffle}', parsedArgs.raffle.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::update
 * @see app/Http/Controllers/RaffleController.php:85
 * @route '/raffles/{raffle}'
 */
update.put = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\RaffleController::update
 * @see app/Http/Controllers/RaffleController.php:85
 * @route '/raffles/{raffle}'
 */
update.patch = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\RaffleController::update
 * @see app/Http/Controllers/RaffleController.php:85
 * @route '/raffles/{raffle}'
 */
    const updateForm = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RaffleController::update
 * @see app/Http/Controllers/RaffleController.php:85
 * @route '/raffles/{raffle}'
 */
        updateForm.put = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\RaffleController::update
 * @see app/Http/Controllers/RaffleController.php:85
 * @route '/raffles/{raffle}'
 */
        updateForm.patch = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\RaffleController::destroy
 * @see app/Http/Controllers/RaffleController.php:121
 * @route '/raffles/{raffle}'
 */
export const destroy = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/raffles/{raffle}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RaffleController::destroy
 * @see app/Http/Controllers/RaffleController.php:121
 * @route '/raffles/{raffle}'
 */
destroy.url = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { raffle: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    raffle: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        raffle: args.raffle,
                }

    return destroy.definition.url
            .replace('{raffle}', parsedArgs.raffle.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::destroy
 * @see app/Http/Controllers/RaffleController.php:121
 * @route '/raffles/{raffle}'
 */
destroy.delete = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RaffleController::destroy
 * @see app/Http/Controllers/RaffleController.php:121
 * @route '/raffles/{raffle}'
 */
    const destroyForm = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RaffleController::destroy
 * @see app/Http/Controllers/RaffleController.php:121
 * @route '/raffles/{raffle}'
 */
        destroyForm.delete = (args: { raffle: string | number } | [raffle: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RaffleController = { winnerSearchView, findWinner, index, create, store, show, edit, update, destroy }

export default RaffleController