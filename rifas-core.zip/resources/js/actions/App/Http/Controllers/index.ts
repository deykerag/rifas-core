import ShoppingController from './ShoppingController'
import DashboardController from './DashboardController'
import RaffleController from './RaffleController'
import UserController from './UserController'
import CompanyController from './CompanyController'
import PaymentMethodController from './PaymentMethodController'
import AwardController from './AwardController'
import SocialNetworkController from './SocialNetworkController'
import CurrencyController from './CurrencyController'
import Settings from './Settings'
const Controllers = {
    ShoppingController: Object.assign(ShoppingController, ShoppingController),
DashboardController: Object.assign(DashboardController, DashboardController),
RaffleController: Object.assign(RaffleController, RaffleController),
UserController: Object.assign(UserController, UserController),
CompanyController: Object.assign(CompanyController, CompanyController),
PaymentMethodController: Object.assign(PaymentMethodController, PaymentMethodController),
AwardController: Object.assign(AwardController, AwardController),
SocialNetworkController: Object.assign(SocialNetworkController, SocialNetworkController),
CurrencyController: Object.assign(CurrencyController, CurrencyController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers