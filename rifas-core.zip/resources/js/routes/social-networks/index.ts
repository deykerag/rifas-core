import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SocialNetworkController::index
 * @see app/Http/Controllers/SocialNetworkController.php:12
 * @route '/social-networks'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/social-networks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SocialNetworkController::index
 * @see app/Http/Controllers/SocialNetworkController.php:12
 * @route '/social-networks'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SocialNetworkController::index
 * @see app/Http/Controllers/SocialNetworkController.php:12
 * @route '/social-networks'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SocialNetworkController::index
 * @see app/Http/Controllers/SocialNetworkController.php:12
 * @route '/social-networks'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SocialNetworkController::index
 * @see app/Http/Controllers/SocialNetworkController.php:12
 * @route '/social-networks'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SocialNetworkController::index
 * @see app/Http/Controllers/SocialNetworkController.php:12
 * @route '/social-networks'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SocialNetworkController::index
 * @see app/Http/Controllers/SocialNetworkController.php:12
 * @route '/social-networks'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SocialNetworkController::create
 * @see app/Http/Controllers/SocialNetworkController.php:23
 * @route '/social-networks/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/social-networks/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SocialNetworkController::create
 * @see app/Http/Controllers/SocialNetworkController.php:23
 * @route '/social-networks/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SocialNetworkController::create
 * @see app/Http/Controllers/SocialNetworkController.php:23
 * @route '/social-networks/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SocialNetworkController::create
 * @see app/Http/Controllers/SocialNetworkController.php:23
 * @route '/social-networks/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SocialNetworkController::create
 * @see app/Http/Controllers/SocialNetworkController.php:23
 * @route '/social-networks/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SocialNetworkController::create
 * @see app/Http/Controllers/SocialNetworkController.php:23
 * @route '/social-networks/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SocialNetworkController::create
 * @see app/Http/Controllers/SocialNetworkController.php:23
 * @route '/social-networks/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\SocialNetworkController::store
 * @see app/Http/Controllers/SocialNetworkController.php:34
 * @route '/social-networks'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/social-networks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SocialNetworkController::store
 * @see app/Http/Controllers/SocialNetworkController.php:34
 * @route '/social-networks'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SocialNetworkController::store
 * @see app/Http/Controllers/SocialNetworkController.php:34
 * @route '/social-networks'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SocialNetworkController::store
 * @see app/Http/Controllers/SocialNetworkController.php:34
 * @route '/social-networks'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SocialNetworkController::store
 * @see app/Http/Controllers/SocialNetworkController.php:34
 * @route '/social-networks'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\SocialNetworkController::show
 * @see app/Http/Controllers/SocialNetworkController.php:0
 * @route '/social-networks/{social_network}'
 */
export const show = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/social-networks/{social_network}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SocialNetworkController::show
 * @see app/Http/Controllers/SocialNetworkController.php:0
 * @route '/social-networks/{social_network}'
 */
show.url = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { social_network: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    social_network: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        social_network: args.social_network,
                }

    return show.definition.url
            .replace('{social_network}', parsedArgs.social_network.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SocialNetworkController::show
 * @see app/Http/Controllers/SocialNetworkController.php:0
 * @route '/social-networks/{social_network}'
 */
show.get = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SocialNetworkController::show
 * @see app/Http/Controllers/SocialNetworkController.php:0
 * @route '/social-networks/{social_network}'
 */
show.head = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SocialNetworkController::show
 * @see app/Http/Controllers/SocialNetworkController.php:0
 * @route '/social-networks/{social_network}'
 */
    const showForm = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SocialNetworkController::show
 * @see app/Http/Controllers/SocialNetworkController.php:0
 * @route '/social-networks/{social_network}'
 */
        showForm.get = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SocialNetworkController::show
 * @see app/Http/Controllers/SocialNetworkController.php:0
 * @route '/social-networks/{social_network}'
 */
        showForm.head = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\SocialNetworkController::edit
 * @see app/Http/Controllers/SocialNetworkController.php:50
 * @route '/social-networks/{social_network}/edit'
 */
export const edit = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/social-networks/{social_network}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SocialNetworkController::edit
 * @see app/Http/Controllers/SocialNetworkController.php:50
 * @route '/social-networks/{social_network}/edit'
 */
edit.url = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { social_network: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    social_network: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        social_network: args.social_network,
                }

    return edit.definition.url
            .replace('{social_network}', parsedArgs.social_network.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SocialNetworkController::edit
 * @see app/Http/Controllers/SocialNetworkController.php:50
 * @route '/social-networks/{social_network}/edit'
 */
edit.get = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SocialNetworkController::edit
 * @see app/Http/Controllers/SocialNetworkController.php:50
 * @route '/social-networks/{social_network}/edit'
 */
edit.head = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SocialNetworkController::edit
 * @see app/Http/Controllers/SocialNetworkController.php:50
 * @route '/social-networks/{social_network}/edit'
 */
    const editForm = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SocialNetworkController::edit
 * @see app/Http/Controllers/SocialNetworkController.php:50
 * @route '/social-networks/{social_network}/edit'
 */
        editForm.get = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SocialNetworkController::edit
 * @see app/Http/Controllers/SocialNetworkController.php:50
 * @route '/social-networks/{social_network}/edit'
 */
        editForm.head = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\SocialNetworkController::update
 * @see app/Http/Controllers/SocialNetworkController.php:63
 * @route '/social-networks/{social_network}'
 */
export const update = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/social-networks/{social_network}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\SocialNetworkController::update
 * @see app/Http/Controllers/SocialNetworkController.php:63
 * @route '/social-networks/{social_network}'
 */
update.url = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { social_network: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    social_network: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        social_network: args.social_network,
                }

    return update.definition.url
            .replace('{social_network}', parsedArgs.social_network.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SocialNetworkController::update
 * @see app/Http/Controllers/SocialNetworkController.php:63
 * @route '/social-networks/{social_network}'
 */
update.put = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\SocialNetworkController::update
 * @see app/Http/Controllers/SocialNetworkController.php:63
 * @route '/social-networks/{social_network}'
 */
update.patch = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\SocialNetworkController::update
 * @see app/Http/Controllers/SocialNetworkController.php:63
 * @route '/social-networks/{social_network}'
 */
    const updateForm = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SocialNetworkController::update
 * @see app/Http/Controllers/SocialNetworkController.php:63
 * @route '/social-networks/{social_network}'
 */
        updateForm.put = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\SocialNetworkController::update
 * @see app/Http/Controllers/SocialNetworkController.php:63
 * @route '/social-networks/{social_network}'
 */
        updateForm.patch = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\SocialNetworkController::destroy
 * @see app/Http/Controllers/SocialNetworkController.php:81
 * @route '/social-networks/{social_network}'
 */
export const destroy = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/social-networks/{social_network}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SocialNetworkController::destroy
 * @see app/Http/Controllers/SocialNetworkController.php:81
 * @route '/social-networks/{social_network}'
 */
destroy.url = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { social_network: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    social_network: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        social_network: args.social_network,
                }

    return destroy.definition.url
            .replace('{social_network}', parsedArgs.social_network.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SocialNetworkController::destroy
 * @see app/Http/Controllers/SocialNetworkController.php:81
 * @route '/social-networks/{social_network}'
 */
destroy.delete = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SocialNetworkController::destroy
 * @see app/Http/Controllers/SocialNetworkController.php:81
 * @route '/social-networks/{social_network}'
 */
    const destroyForm = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SocialNetworkController::destroy
 * @see app/Http/Controllers/SocialNetworkController.php:81
 * @route '/social-networks/{social_network}'
 */
        destroyForm.delete = (args: { social_network: string | number } | [social_network: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const socialNetworks = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default socialNetworks