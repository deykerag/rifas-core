import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\RaffleController::winnerSearch
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
export const winnerSearch = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: winnerSearch.url(options),
    method: 'get',
})

winnerSearch.definition = {
    methods: ["get","head"],
    url: '/dashboard/winner-search',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RaffleController::winnerSearch
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
winnerSearch.url = (options?: RouteQueryOptions) => {
    return winnerSearch.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::winnerSearch
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
winnerSearch.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: winnerSearch.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RaffleController::winnerSearch
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
winnerSearch.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: winnerSearch.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RaffleController::winnerSearch
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
    const winnerSearchForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: winnerSearch.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RaffleController::winnerSearch
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
        winnerSearchForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: winnerSearch.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RaffleController::winnerSearch
 * @see app/Http/Controllers/RaffleController.php:129
 * @route '/dashboard/winner-search'
 */
        winnerSearchForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: winnerSearch.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    winnerSearch.form = winnerSearchForm
/**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
export const findWinner = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: findWinner.url(options),
    method: 'post',
})

findWinner.definition = {
    methods: ["post"],
    url: '/dashboard/find-winner',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
findWinner.url = (options?: RouteQueryOptions) => {
    return findWinner.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
findWinner.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: findWinner.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
    const findWinnerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: findWinner.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RaffleController::findWinner
 * @see app/Http/Controllers/RaffleController.php:136
 * @route '/dashboard/find-winner'
 */
        findWinnerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: findWinner.url(options),
            method: 'post',
        })
    
    findWinner.form = findWinnerForm
const dashboard = {
    winnerSearch: Object.assign(winnerSearch, winnerSearch),
findWinner: Object.assign(findWinner, findWinner),
}

export default dashboard