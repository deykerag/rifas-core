import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ShoppingController::index
 * @see app/Http/Controllers/ShoppingController.php:14
 * @route '/shoppings'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/shoppings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShoppingController::index
 * @see app/Http/Controllers/ShoppingController.php:14
 * @route '/shoppings'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::index
 * @see app/Http/Controllers/ShoppingController.php:14
 * @route '/shoppings'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShoppingController::index
 * @see app/Http/Controllers/ShoppingController.php:14
 * @route '/shoppings'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShoppingController::index
 * @see app/Http/Controllers/ShoppingController.php:14
 * @route '/shoppings'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::index
 * @see app/Http/Controllers/ShoppingController.php:14
 * @route '/shoppings'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShoppingController::index
 * @see app/Http/Controllers/ShoppingController.php:14
 * @route '/shoppings'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ShoppingController::create
 * @see app/Http/Controllers/ShoppingController.php:25
 * @route '/shoppings/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/shoppings/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShoppingController::create
 * @see app/Http/Controllers/ShoppingController.php:25
 * @route '/shoppings/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::create
 * @see app/Http/Controllers/ShoppingController.php:25
 * @route '/shoppings/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShoppingController::create
 * @see app/Http/Controllers/ShoppingController.php:25
 * @route '/shoppings/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShoppingController::create
 * @see app/Http/Controllers/ShoppingController.php:25
 * @route '/shoppings/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::create
 * @see app/Http/Controllers/ShoppingController.php:25
 * @route '/shoppings/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShoppingController::create
 * @see app/Http/Controllers/ShoppingController.php:25
 * @route '/shoppings/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\ShoppingController::store
 * @see app/Http/Controllers/ShoppingController.php:38
 * @route '/shoppings'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/shoppings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShoppingController::store
 * @see app/Http/Controllers/ShoppingController.php:38
 * @route '/shoppings'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::store
 * @see app/Http/Controllers/ShoppingController.php:38
 * @route '/shoppings'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ShoppingController::store
 * @see app/Http/Controllers/ShoppingController.php:38
 * @route '/shoppings'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::store
 * @see app/Http/Controllers/ShoppingController.php:38
 * @route '/shoppings'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ShoppingController::show
 * @see app/Http/Controllers/ShoppingController.php:0
 * @route '/shoppings/{shopping}'
 */
export const show = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/shoppings/{shopping}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShoppingController::show
 * @see app/Http/Controllers/ShoppingController.php:0
 * @route '/shoppings/{shopping}'
 */
show.url = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shopping: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    shopping: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shopping: args.shopping,
                }

    return show.definition.url
            .replace('{shopping}', parsedArgs.shopping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::show
 * @see app/Http/Controllers/ShoppingController.php:0
 * @route '/shoppings/{shopping}'
 */
show.get = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShoppingController::show
 * @see app/Http/Controllers/ShoppingController.php:0
 * @route '/shoppings/{shopping}'
 */
show.head = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShoppingController::show
 * @see app/Http/Controllers/ShoppingController.php:0
 * @route '/shoppings/{shopping}'
 */
    const showForm = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::show
 * @see app/Http/Controllers/ShoppingController.php:0
 * @route '/shoppings/{shopping}'
 */
        showForm.get = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShoppingController::show
 * @see app/Http/Controllers/ShoppingController.php:0
 * @route '/shoppings/{shopping}'
 */
        showForm.head = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ShoppingController::edit
 * @see app/Http/Controllers/ShoppingController.php:87
 * @route '/shoppings/{shopping}/edit'
 */
export const edit = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/shoppings/{shopping}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ShoppingController::edit
 * @see app/Http/Controllers/ShoppingController.php:87
 * @route '/shoppings/{shopping}/edit'
 */
edit.url = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shopping: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    shopping: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shopping: args.shopping,
                }

    return edit.definition.url
            .replace('{shopping}', parsedArgs.shopping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::edit
 * @see app/Http/Controllers/ShoppingController.php:87
 * @route '/shoppings/{shopping}/edit'
 */
edit.get = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ShoppingController::edit
 * @see app/Http/Controllers/ShoppingController.php:87
 * @route '/shoppings/{shopping}/edit'
 */
edit.head = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ShoppingController::edit
 * @see app/Http/Controllers/ShoppingController.php:87
 * @route '/shoppings/{shopping}/edit'
 */
    const editForm = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::edit
 * @see app/Http/Controllers/ShoppingController.php:87
 * @route '/shoppings/{shopping}/edit'
 */
        editForm.get = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ShoppingController::edit
 * @see app/Http/Controllers/ShoppingController.php:87
 * @route '/shoppings/{shopping}/edit'
 */
        editForm.head = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\ShoppingController::update
 * @see app/Http/Controllers/ShoppingController.php:102
 * @route '/shoppings/{shopping}'
 */
export const update = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/shoppings/{shopping}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ShoppingController::update
 * @see app/Http/Controllers/ShoppingController.php:102
 * @route '/shoppings/{shopping}'
 */
update.url = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shopping: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    shopping: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shopping: args.shopping,
                }

    return update.definition.url
            .replace('{shopping}', parsedArgs.shopping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::update
 * @see app/Http/Controllers/ShoppingController.php:102
 * @route '/shoppings/{shopping}'
 */
update.put = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\ShoppingController::update
 * @see app/Http/Controllers/ShoppingController.php:102
 * @route '/shoppings/{shopping}'
 */
update.patch = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ShoppingController::update
 * @see app/Http/Controllers/ShoppingController.php:102
 * @route '/shoppings/{shopping}'
 */
    const updateForm = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::update
 * @see app/Http/Controllers/ShoppingController.php:102
 * @route '/shoppings/{shopping}'
 */
        updateForm.put = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\ShoppingController::update
 * @see app/Http/Controllers/ShoppingController.php:102
 * @route '/shoppings/{shopping}'
 */
        updateForm.patch = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ShoppingController::destroy
 * @see app/Http/Controllers/ShoppingController.php:152
 * @route '/shoppings/{shopping}'
 */
export const destroy = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/shoppings/{shopping}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ShoppingController::destroy
 * @see app/Http/Controllers/ShoppingController.php:152
 * @route '/shoppings/{shopping}'
 */
destroy.url = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shopping: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    shopping: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shopping: args.shopping,
                }

    return destroy.definition.url
            .replace('{shopping}', parsedArgs.shopping.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::destroy
 * @see app/Http/Controllers/ShoppingController.php:152
 * @route '/shoppings/{shopping}'
 */
destroy.delete = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ShoppingController::destroy
 * @see app/Http/Controllers/ShoppingController.php:152
 * @route '/shoppings/{shopping}'
 */
    const destroyForm = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::destroy
 * @see app/Http/Controllers/ShoppingController.php:152
 * @route '/shoppings/{shopping}'
 */
        destroyForm.delete = (args: { shopping: string | number } | [shopping: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const shoppings = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default shoppings