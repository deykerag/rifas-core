import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ShoppingController::ticket
 * @see app/Http/Controllers/ShoppingController.php:160
 * @route '/verify-ticket'
 */
export const ticket = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ticket.url(options),
    method: 'post',
})

ticket.definition = {
    methods: ["post"],
    url: '/verify-ticket',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShoppingController::ticket
 * @see app/Http/Controllers/ShoppingController.php:160
 * @route '/verify-ticket'
 */
ticket.url = (options?: RouteQueryOptions) => {
    return ticket.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShoppingController::ticket
 * @see app/Http/Controllers/ShoppingController.php:160
 * @route '/verify-ticket'
 */
ticket.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ticket.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ShoppingController::ticket
 * @see app/Http/Controllers/ShoppingController.php:160
 * @route '/verify-ticket'
 */
    const ticketForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ticket.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShoppingController::ticket
 * @see app/Http/Controllers/ShoppingController.php:160
 * @route '/verify-ticket'
 */
        ticketForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ticket.url(options),
            method: 'post',
        })
    
    ticket.form = ticketForm
const verify = {
    ticket: Object.assign(ticket, ticket),
}

export default verify